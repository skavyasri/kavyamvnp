package com.niit.musicalinstrumentcatr.dao;

import com.niit.musicalinstrumentcatr.model.User;

public interface UserDAO {
	
public void adduser(User user);
}
