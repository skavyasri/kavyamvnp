package com.niit.musicalinstrumentcatr.dao;

import javax.management.loading.PrivateClassLoader;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.niit.musicalinstrumentcatr.model.User;
@Repository("UserDAO")
@EnableTransactionManagement


public class UserDAOImpl implements UserDAO{
	@Autowired
	private SessionFactory sessionFactory;
	


	public UserDAOImpl(SessionFactory sessionFactory) {
		
		this.sessionFactory = sessionFactory;
	}
	


@Transactional
	public void adduser(User user)
	{
		sessionFactory.getCurrentSession().saveOrUpdate(user);		
	}
	
}