package com.niit.musicalinstrumentcatr.yest;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.musicalinstrumentcatr.dao.UserDAO;
import com.niit.musicalinstrumentcatr.model.User;

public class userTest 
{
  public static void main(String[] args)
  {
	  AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
	   context.scan("com.niit.musicalinstrumentcatr");
	  context.refresh();
	  
	  UserDAO userDAO=(UserDAO)context.getBean("UserDAO");
	  User user =(User) context.getBean("user");
	  
	  user.setName("sharath");
	  user.setPassword("sharath");
	  user.setAddress("vjngr");
	  user.setPhone("997031332");
	  
	  userDAO.adduser(user);
	  	  	  	  	  
  }

}

